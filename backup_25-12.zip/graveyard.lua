graveyard:

    --we should clean the inventory
    print("inventory cleanup cycle")
    for cleanIter=1,16 do
        turtle.select(cleanIter)
        if turtle.getItemSpace(cleanIter) ~= 64 then
            local founditem = turtle.getItemDetail(cleanIter).name
            for i,v in ipairs(badblocks) do
                if v == founditem then
                    turtle.dropUp()
                end
            end
        end
    end